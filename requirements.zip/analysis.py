from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

# --- Hyperparameters ---
MODEL_NAME = 'distilbert-base-uncased'
MAX_LEN = 10
MODEL_SAVE_PATH = 'best_goemotions_model.pt'

# --- Load Tokenizer and Model ---
tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
model = AutoModelForSequenceClassification.from_pretrained(MODEL_NAME, num_labels=28)
model.load_state_dict(torch.load(MODEL_SAVE_PATH, map_location=torch.device("cpu")))
model.eval()

# --- Emotion categories ---
positive_emotions = ['amusement', 'joy', 'approval', 'caring', 'curiosity', 'excitement', 'gratitude', 'love', 'optimism', 'pride', 'realization', 'relief']
negative_emotions = ['anger', 'annoyance', 'disappointment', 'disapproval', 'disgust', 'embarrassment', 'fear', 'grief', 'nervousness', 'remorse', 'sadness', 'surprise']
neutral_emotions = ['neutral']

emotions = [
    'admiration', 'amusement', 'anger', 'annoyance', 'approval', 'caring',
    'confusion', 'curiosity', 'desire', 'disappointment', 'disapproval',
    'disgust', 'embarrassment', 'excitement', 'fear', 'gratitude', 'grief',
    'joy', 'love', 'nervousness', 'optimism', 'pride', 'realization',
    'relief', 'remorse', 'sadness', 'surprise', 'neutral'
]

# --- FastAPI-compatible function ---
def analyze_text(input_text: str):
    inputs = tokenizer.encode_plus(
        input_text,
        add_special_tokens=True,
        max_length=MAX_LEN,
        padding='max_length',
        truncation=True,
        return_attention_mask=True,
        return_tensors='pt',
    )

    with torch.no_grad():
        outputs = model(**inputs)
        probs = torch.sigmoid(outputs.logits).squeeze().tolist()

    emotion_probs = list(zip(emotions, probs))
    top5 = sorted(emotion_probs, key=lambda x: x[1], reverse=True)[:5]

    # Score calculation
    pos_score = sum(prob for emo, prob in top5 if emo in positive_emotions)
    neg_score = sum(prob for emo, prob in top5 if emo in negative_emotions)
    final_score = pos_score - neg_score

    # Sentiment level logic
    if final_score > 0.7:
        sentiment_level = "green"#"GREEN - Positive"
    elif 0 < final_score <= 0.7:
        sentiment_level = "yellow"#"YELLOW - Most likely Positive"
    elif -0.7 <= final_score < 0:
        sentiment_level = "orange" #"ORANGE - Most likely Negative"
    else:
        sentiment_level = "red" #"RED - Negative"

    # Return result
    return {
        "sentiment_level": sentiment_level
    }
